//
//  ViewController.m
//  录制视频添加背景音乐
//
//  Created by liweidong on 17/7/31.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "ViewController.h"
#import "EditAudioVideo.h"

#import "FinshViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}
- (IBAction)click:(id)sender {
    //正在添加背景音乐
    
    [EditAudioVideo editVideoSynthesizeVieoPath:[self filePathName:@"abc.mp4"] BGMPath:[self filePathName:@"123.mp3"] needOriginalVoice:YES videoVolume:0 BGMVolume:1 complition:^(NSURL *outputPath, BOOL isSucceed) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            //添加背景音乐完成
            FinshViewController *finshVC = [FinshViewController new];
            finshVC.playURL = outputPath;
            [self presentViewController:finshVC animated:YES completion:nil];
        });
        
    }];

}

- (NSURL *)filePathName:(NSString *)fileName{
    return [NSURL fileURLWithPath:[[NSBundle mainBundle]pathForResource:fileName ofType:nil]];
}

@end
