//
//  EditViewController.h
//  AudioVideoEdit
//
//  Created by cuctv-duan on 17/2/13.
//  Copyright © 2017年 duan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EditViewController : UIViewController

@end
