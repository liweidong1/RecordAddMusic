# AudioVideoEdit
仿秒拍音视频合成
Demo简书博客地址：[http://www.jianshu.com/p/f851970cb8ee](http://www.jianshu.com/p/f851970cb8ee)
